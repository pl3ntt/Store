﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static cursova1.MainForm;

namespace cursova1
{
    public partial class DiscountForm : Form
    {
        private List<Product> _products;
        public Product SelectedProduct { get; private set; }
        public decimal NewPrice { get; private set; }
        public DiscountForm(List<Product> products)
        {
            InitializeComponent();
            _products = products;
            comboBoxProduct.DataSource = _products.Select(p => $"{p.Name}__{p.Unit}").ToList();
        }

        private void buttonApplyDiscount_Click(object sender, EventArgs e)
        {
            try
            {
                string selected = comboBoxProduct.SelectedItem.ToString();
                string[] parts = selected.Split(new[] { "__" }, StringSplitOptions.None);
                string name = parts[0].Trim();
                string unit = parts[1].Trim();

                var product = _products.FirstOrDefault(p => p.Name == name && p.Unit == unit);
                decimal price = decimal.Parse(textBoxNewPrice.Text);

                if (price <= 0 || price >= product.Price)
                {
                    MessageBox.Show("Нова ціна має бути меншою за поточну та більшою за нуль.");
                    return;
                }

                SelectedProduct = product;
                NewPrice = price;

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка: " + ex.Message);
            }
        }

        private void DiscountForm_Load(object sender, EventArgs e)
        {

        }
    }
}

