﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;
using System.IO;
using Newtonsoft.Json;
using Microsoft.VisualBasic;

namespace cursova1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            LoadProductsFromFile();
        }

        public class Product
        {
            public string Name { get; set; }
            public string Unit { get; set; }
            public decimal Price { get; set; }
            public int Quantity { get; set; }
            public DateTime LastDeliveryDate { get; set; }
            public decimal TotalValue => Price * Quantity;
        }

        ProductCollection products = new ProductCollection();

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveProductsToFile();
        }

        private void SaveProductsToFile()
        {
            try
            {
                products.SaveToFile("products.json");
                MessageBox.Show("Збережено успішно!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка збереження: {ex.Message}");
            }
        }

        private void LoadProductsFromFile()
        {
            products.LoadFromFile("products.json");
            products.UpdateGrid(DataGridViewMainForm);
        }


        private void UpdateDataGrid()
        {
            products.UpdateGrid(DataGridViewMainForm);
        }

        private void Income_Click(object sender, EventArgs e)
        {
            using (FormIncome form = new FormIncome())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    var newProduct = form.NewProduct;

                    var existing = products.GetAll().FirstOrDefault(p => p.Name == newProduct.Name && p.Unit == newProduct.Unit);
                    if (existing != null)
                    {
                        existing.Quantity += newProduct.Quantity;
                        existing.Price = newProduct.Price;
                        existing.LastDeliveryDate = DateTime.Now;
                    }
                    else
                    {
                        products.Add(newProduct);
                    }

                    UpdateDataGrid();
                }
            }
        }

        private void Sale_Click(object sender, EventArgs e)
        {
            using (SaleForm form = new SaleForm(products.GetAll()))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    foreach (var item in form.FinalSale)
                    {
                        var product = products.GetAll().FirstOrDefault(p =>
                            p.Name == item.Product.Name && p.Unit == item.Product.Unit);
                        if (product != null)
                        {
                            product.Quantity -= item.Quantity;
                        }
                    }
                    
                    UpdateDataGrid();
                    MessageBox.Show("Покупка оформлена.");
                }
            }
        }

        private void WriteOff_Click(object sender, EventArgs e)
        {
            using (WriteOffForm form = new WriteOffForm(products.GetAll()))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    var product = form.SelectedProduct;
                    int qty = form.QuantityToWriteOff;
                    string reason = form.Reason;

                    product.Quantity -= qty;

                    MessageBox.Show($"Списано:\n{product.Name} × {qty} шт\nПричина: {reason}",
                        "Списання", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    UpdateDataGrid();
                }
            }
        }

        private void Discount_Click(object sender, EventArgs e)
        {
            using (DiscountForm form = new DiscountForm(products.GetAll()))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    var product = form.SelectedProduct;
                    decimal newPrice = form.NewPrice;

                    decimal oldPrice = product.Price;
                    product.Price = newPrice;
                    product.LastDeliveryDate = DateTime.Now;

                    MessageBox.Show($"Ціну знижено:\n{product.Name}\n{oldPrice} → {newPrice}",
                        "Уцінка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    UpdateDataGrid();
                }
            }
        }

        private void Inventory_Click(object sender, EventArgs e)
        {
            using (InventoryForm form = new InventoryForm(products.GetAll()))
            {
                form.ShowDialog();
            }
        }

        private void DataGridViewMainForm_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void EditProduct_Click(object sender, EventArgs e)
        {
            if (DataGridViewMainForm.CurrentRow == null)
            {
                MessageBox.Show("Будь ласка, виберіть товар для редагування.");
                return;
            }

            int index = DataGridViewMainForm.CurrentRow.Index;

            if (index < 0 || index >= products.Count)
            {
                MessageBox.Show("Некоректний вибір.");
                return;
            }

            Product product = products[index];

            using (var editForm = new EditProductForm(product.Name, product.Unit, product.Price, product.Quantity))
            {
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    product.Name = editForm.ProductName;
                    product.Unit = editForm.Unit;
                    product.Price = editForm.Price;
                    product.Quantity = (int)editForm.Quantity;

                    UpdateDataGrid();
                    SaveProductsToFile();

                    MessageBox.Show("Товар успішно оновлено.");
                }
            }
        }

        private void DeleteProduct_Click(object sender, EventArgs e)
        {
            if (DataGridViewMainForm.CurrentRow == null)
            {
                MessageBox.Show("Будь ласка, виберіть товар для видалення.");
                return;
            }

            int index = DataGridViewMainForm.CurrentRow.Index;
            if (index < 0 || index >= products.Count)
            {
                MessageBox.Show("Некоректний вибір.");
                return;
            }

            Product product = products[index];

            using (var confirmForm = new ConfirmDeleteForm(product.Name))
            {
                if (confirmForm.ShowDialog() == DialogResult.Yes)
                {
                    products.RemoveAt(index);
                    UpdateDataGrid();
                    SaveProductsToFile();
                    MessageBox.Show("Товар видалено.");
                }
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            string searchText = textBoxSearch.Text.Trim().ToLower();

            var filtered = products.GetAll()
                .Where(p => p.Name.ToLower().Contains(searchText))
                .Select(p => new
                {
                    Назва = p.Name,
                    Одиниця_виміру = p.Unit,
                    Ціна = p.Price,
                    Кількість = p.Quantity,
                    Дата_завезення = p.LastDeliveryDate,
                    Сума = p.TotalValue
                })
                .ToList();

            DataGridViewMainForm.DataSource = null;
            DataGridViewMainForm.DataSource = filtered;
        }

        private void buttonResetSearch_Click(object sender, EventArgs e)
        {
            textBoxSearch.Text = "";
            products.UpdateGrid(DataGridViewMainForm);
        }

    }
}
