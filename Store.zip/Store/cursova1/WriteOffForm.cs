﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static cursova1.MainForm;

namespace cursova1
{
    public partial class WriteOffForm : Form
    {
        private List<Product> _products;
        public Product SelectedProduct { get; private set; }
        public int QuantityToWriteOff { get; private set; }
        public string Reason { get; private set; }

        public WriteOffForm(List<Product> products)
        {
            InitializeComponent();
            _products = products;
            comboBoxProduct.DataSource = _products.Select(p => $"{p.Name}__{p.Unit}").ToList();
        }

        private void buttonWriteOff_Click(object sender, EventArgs e)
        {
            try
            {
                string selected = comboBoxProduct.SelectedItem.ToString();
                string[] parts = selected.Split(new[] { "__" }, StringSplitOptions.None);
                string name = parts[0].Trim();
                string unit = parts[1].Trim();

                int qty = int.Parse(textBoxQuantity.Text);
                string reason = textBoxReason.Text;

                var product = _products.FirstOrDefault(p => p.Name == name && p.Unit == unit);

                if (qty <= 0 || qty > product.Quantity)
                {
                    MessageBox.Show("Некоректна кількість");
                    return;
                }

                SelectedProduct = product;
                QuantityToWriteOff = qty;
                Reason = reason;

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка: " + ex.Message);
            }
        }

        private void WriteOffForm_Load(object sender, EventArgs e)
        {

        }
    }
}
