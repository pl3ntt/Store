﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static cursova1.MainForm;

namespace cursova1
{
    public partial class FormIncome : Form
    {
        public Product NewProduct { get; private set; }

        public FormIncome()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                NewProduct = new MainForm.Product
                {
                    Name = textBoxName.Text,
                    Unit = textBoxUnit.Text,
                    Price = decimal.Parse(textBoxPrice.Text),
                    Quantity = int.Parse(textBoxQuantity.Text),
                    LastDeliveryDate = DateTime.Now
                };

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка введення: " + ex.Message);
            }
        }

        private void FormIncome_Load(object sender, EventArgs e)
        {

        }
    }
}
