﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cursova1
{
    public partial class EditProductForm : Form
    {
        public string ProductName => textBoxName.Text;
        public string Unit => textBoxUnit.Text;

        public decimal Price
        {
            get
            {
                if (decimal.TryParse(textBoxPrice.Text, out decimal result))
                    return result;
                return 0;
            }
        }

        public decimal Quantity
        {
            get
            {
                if (decimal.TryParse(textBoxQuantity.Text, out decimal result))
                    return result;
                return 0;
            }
        }

        public EditProductForm(string name, string unit, decimal price, decimal quantity)
        {
            InitializeComponent();

            textBoxName.Text = name;
            textBoxUnit.Text = unit;
            textBoxPrice.Text = price.ToString();
            textBoxQuantity.Text = quantity.ToString();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ProductName) || string.IsNullOrWhiteSpace(Unit))
            {
                MessageBox.Show("Назва та одиниця виміру не можуть бути порожніми.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Price <= 0 || Quantity < 0)
            {
                MessageBox.Show("Ціна має бути > 0, кількість ≥ 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
