﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static cursova1.MainForm;

namespace cursova1
{
    public partial class SaleForm : Form
    {
        private List<Product> availableProducts;
        private List<SaleItem> cart = new List<SaleItem>();

        public List<SaleItem> FinalSale => cart;

        public SaleForm(List<Product> products)
        {
            InitializeComponent();
            availableProducts = products;
            this.Load += SaleForm_Load;
        }

        private void SaleForm_Load(object sender, EventArgs e)
        {
            comboBoxProduct.DataSource = availableProducts
                .Select(p => $"{p.Name} ({p.Unit})")
                .Distinct()
                .ToList();
        }
        private void buttonAddToCart_Click(object sender, EventArgs e)
        {
            string selectedItem = comboBoxProduct.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedItem)) return;

            if (!int.TryParse(textBoxQuantity.Text, out int qty) || qty <= 0)
            {
                MessageBox.Show("Некоректна кількість");
                return;
            }

            var parts = selectedItem.Split(new[] { " (" }, StringSplitOptions.None);
            string name = parts[0];
            string unit = parts[1].TrimEnd(')');

            var product = availableProducts
                .FirstOrDefault(p => p.Name == name && p.Unit == unit);

            int alreadyInCart = cart
                .Where(c => c.Product.Name == name && c.Product.Unit == unit)
                .Sum(c => c.Quantity);

            int remainingStock = product.Quantity - alreadyInCart; 

            if (qty > remainingStock)
            {
                MessageBox.Show($"На складі залишилось тільки {remainingStock} одиниць.");
                return;
            }

            cart.Add(new SaleItem { Product = product, Quantity = qty });

            dataGridViewCart.DataSource = null;
            dataGridViewCart.DataSource = cart.Select(c => new
            {
                Назва = c.Product.Name,
                Кількість = c.Quantity,
                Ціна = c.Product.Price,
                Сума = c.Quantity * c.Product.Price
            }).ToList();
        }
        private string GenerateReceipt()
        {
            StringBuilder receipt = new StringBuilder();
            receipt.AppendLine("ЧЕК");
            receipt.AppendLine("Дата: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm"));
            receipt.AppendLine("-------------------------");

            decimal total = 0;
            foreach (var item in cart)
            {
                decimal sum = item.Quantity * item.Product.Price;
                total += sum;
                receipt.AppendLine($"{item.Product.Name} ({item.Product.Unit}) x {item.Quantity} = {sum:0.00} грн");
            }

            receipt.AppendLine("-------------------------");
            receipt.AppendLine($"Загалом: {total:0.00} грн");

            return receipt.ToString();
        }

        private void buttonCheckout_Click(object sender, EventArgs e)
        {
            if (cart.Count == 0)
            {
                MessageBox.Show("Кошик порожній.");
                return;
            }

            string receipt = GenerateReceipt();
            string directory = Path.Combine(Application.StartupPath, "Receipts");
            Directory.CreateDirectory(directory);

            string filename = $"Чек_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
            string fullPath = Path.Combine(directory, filename);

            File.WriteAllText(fullPath, receipt);
            System.Diagnostics.Process.Start("notepad.exe", fullPath);
            MessageBox.Show("Покупка оформлена. Чек збережено.");

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        public class SaleItem
        {
            public Product Product { get; set; }
            public int Quantity { get; set; }
        }

    }
}
