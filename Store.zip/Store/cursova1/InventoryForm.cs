﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static cursova1.MainForm;

namespace cursova1
{
    public partial class InventoryForm : Form
    {
        private List<Product> _products;

        public InventoryForm(List<Product> products)
        {
            InitializeComponent();
            _products = products;

            LoadInventory();
        }

        private void LoadInventory()
        {
            var data = _products.Select(p => new
            {
                Назва = p.Name,
                Одиниця_виміру = p.Unit,
                Ціна = p.Price,
                Кількість = p.Quantity,
                Дата_завезення = p.LastDeliveryDate,
                Сума = p.TotalValue
            }).ToList();

            dataGridViewInventory.DataSource = data;

            decimal total = _products.Sum(p => p.TotalValue);
            labelTotalValue.Text = $"Загальна вартість залишків: {total:C}";
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
