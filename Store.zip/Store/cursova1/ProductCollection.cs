﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;

namespace cursova1
{
    public class ProductCollection
    {
        private List<MainForm.Product> products = new List<MainForm.Product>();

        public List<MainForm.Product> GetAll()
        {
            return products;
        }

        public void Add(MainForm.Product product)
        {
            products.Add(product);
        }

        public void RemoveAt(int index)
        {
            if (index >= 0 && index < products.Count)
            {
                products.RemoveAt(index);
            }
        }

        public MainForm.Product this[int index] => products[index];

        public int Count => products.Count;

        public void SaveToFile(string filePath)
        {
            string json = JsonConvert.SerializeObject(products, Formatting.Indented);
            File.WriteAllText(filePath, json);
        }

        public void LoadFromFile(string filePath)
        {
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                products = JsonConvert.DeserializeObject<List<MainForm.Product>>(json);
            }
        }

        public MainForm.Product FindByName(string name)
        {
            return products.Find(p => p.Name == name);
        }

        public void UpdateGrid(DataGridView grid)
        {
            grid.DataSource = null;
            grid.DataSource = products.Select(p => new
            {
                Назва = p.Name,
                Одиниця_виміру = p.Unit,
                Ціна = p.Price,
                Кількість = p.Quantity,
                Дата_завезення = p.LastDeliveryDate,
                Сума = p.TotalValue
            }).ToList();
        }
    }
}
